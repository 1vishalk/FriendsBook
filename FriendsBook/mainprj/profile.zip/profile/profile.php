<html>
<head>
<title>chatbook
</title>
<link type="text/css" rel ="stylesheet" href="prof3.css"/>
<script src="jquery.js"></script>
<script>$(document).ready(function(){
$(".box13").click(function(){
$(".box13").css('background-color','#e9f0f2');
$(".box11").css('background-color','white');
$(".box12").css('background-color','white');
$(".box14").css('background-color','white');
		$(".frnpad").fadeIn("slow");
		$(".frnpadx").fadeIn("slow");
				$(".aboutpad").fadeOut("slow");
		$(".aboutpadx").fadeOut("slow");
				$(".phpadx").fadeOut("slow");
        $(".phpadx").fadeOut("slow");
				$(".postp").fadeOut("slow");
		$(".postpx").fadeOut("slow");
				$(".post1p").fadeOut("slow");
		$(".post1px").fadeOut("slow");
				$(".abox1").fadeOut("slow");
		$(".abox1x").fadeOut("slow");
				$(".abox2").fadeOut("slow");
		$(".abox2x").fadeOut("slow");
				$(".abox3").fadeOut("slow");
		$(".abox3x").fadeOut("slow");
});
$(".box14").click(function(){
$(".box14").css('background-color','#e9f0f2');
$(".box11").css('background-color','white');
$(".box12").css('background-color','white');
$(".box13").css('background-color','white');
				$(".phpadx").fadeOut("slow");
        $(".phpadx").fadeOut("slow");
				$(".aboutpad").fadeOut("slow");
		$(".aboutpadx").fadeOut("slow");
				$(".frnpad").fadeIn("slow");
		$(".frnpadx").fadeIn("slow");
				$(".postp").fadeOut("slow");
		$(".postpx").fadeOut("slow");
				$(".post1p").fadeOut("slow");
		$(".post1px").fadeOut("slow");
				$(".abox1").fadeOut("slow");
		$(".abox1x").fadeOut("slow");
				$(".abox2").fadeOut("slow");
		$(".abox2x").fadeOut("slow");
				$(".abox3").fadeOut("slow");
		$(".abox3x").fadeOut("slow");
});
$(".box12").click(function(){
$(".box12").css('background-color','#e9f0f2');
$(".box11").css('background-color','white');
$(".box13").css('background-color','white');
$(".box14").css('background-color','white');
				$(".aboutpad").fadeOut("slow");
		$(".aboutpadx").fadeOut("slow");
				$(".frnpad").fadeIn("slow");
		$(".frnpadx").fadeIn("slow");
				$(".phpadx").fadeOut("slow");
        $(".phpadx").fadeOut("slow");
				$(".postp").fadeOut("slow");
		$(".postpx").fadeOut("slow");
				$(".post1p").fadeOut("slow");
		$(".post1px").fadeOut("slow");
				$(".abox1").fadeOut("slow");
		$(".abox1x").fadeOut("slow");
				$(".abox2").fadeOut("slow");
		$(".abox2x").fadeOut("slow");
				$(".abox3").fadeOut("slow");
		$(".abox3x").fadeOut("slow");
});
$(".box11").click(function(){
$(".box11").css('background-color','#e9f0f2');
$(".box12").css('background-color','white');
$(".box13").css('background-color','white');
$(".box14").css('background-color','white');
				$(".aboutpad").fadeOut("slow");
		$(".aboutpadx").fadeOut("slow");
				$(".postp").fadeOut("slow");
		$(".postpx").fadeOut("slow");
				$(".post1p").fadeOut("slow");
		$(".post1px").fadeOut("slow");
				$(".abox1").fadeOut("slow");
		$(".abox1x").fadeOut("slow");
				$(".abox2").fadeOut("slow");
		$(".abox2x").fadeOut("slow");
				$(".abox3").fadeOut("slow");
		$(".abox3x").fadeOut("slow");
				$(".frnpad").fadeIn("slow");
		$(".frnpadx").fadeIn("slow");
				$(".phpadx").fadeOut("slow");
        $(".phpadx").fadeOut("slow");
		
});
$(".box13").click(function(){})


});
</script>
</head>
<body>
<div class="header1">
<div id="img3" class ="header1"><img src="llLy.jpg"height="45px" width="90px"/></div>
<div id="searcharea" class ="header1"><input placeholder="search here..." type="text" id="searchbox"/></div>
<div id="profilearea" class ="header1"><img src="profil.png"height="40px" width="40px"/></div>
<div id="profilearea1" class ="header1">profile</div>
<div id="profilearea3" class ="header1">|</div>
<div id="profilearea4" class ="header1"><a href="home11.php">home</a></div>
<div id="findf" class ="header1"><img src="frn.png" height="60px" width="50px"/></div>
<div id="message" class ="header1"><img src="chat.png" height="40px" width="35px"/></div>
<div id="notification" class ="header1"><img src="noti.png" height="40px" width="40px"/></div>
<div id="profilearea2" class ="header1">|</div>
<div id="setting" class ="header1"><img src="set.png" height="45px" width="40px" /></div>
<div id="logout" class ="header1"><img src="lo.png" height="40px" width="40px"/></div>
</div>

<div class="header0001">
</div>

<div class="coverpad">
</div>
<div class="coverpadx"><img src="cover.jpg" height="400px" width="700px"/>
</div>

<div class="profilepic">
</div>
<div class="profilepic"><img src="kid.jpg" height="140px" width="220px"/>
</div>

<div class="username" >shwetasmina nayak
</div>
<div class="box11">Timeline
</div>
<div class="box12">About
</div>
<div class="box13">Friends
</div>
<div class="box14">Photos
</div>

<select>
<option selected>more</option>
<option value="saab">videos</option>
<option value="opel">places</option>
<option value="audi">pages</option>
</select>

<div class="postpx">
</div>
</div>
<div class="post1px">
</div>
<div class="post1p"><img src="profil.jpg"/><br><br>
<img src="rogor.jpg" height="411" width="580" /><br><br><p6>like comment share</p6><br><br><p1>Amit Deb</p1><p2>and</p2><p1>5 other</p1><p2>like this</p2>
<div id="post2text" class="post1p"><p3>Rani Mukharji</p3><p2>with</p2><p1>Arup Pegu</p1><p2>and</p2><p1>15 others.</p1><p4>4 hrs</p4></div>
<div id="commentprof2" class="post1p"><img src="profil.png"/></div>
<div id="commentboxpos2" class="post1p"><input type="textarea" placeholder="comment" id="commentbox"/></div>
</div>
</div>

</div>
</body>
</html>